
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report
import lime
import lime.lime_tabular
import matplotlib.pyplot as plt
import joblib

# 1. Carregar dados
df = pd.read_csv("data/german_credit_data.csv")

# 2. Pré-processamento simples
df = df.dropna()
target = 'Risk'
X = df.drop(columns=[target])
y = df[target]

# Encoding de variáveis categóricas
for col in X.select_dtypes(include='object'):
    X[col] = LabelEncoder().fit_transform(X[col])

y = LabelEncoder().fit_transform(y)  # 1 = good, 0 = bad

# 3. Divisão treino/teste
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# 4. Treinar modelo
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# 5. Avaliação
print("Relatório de Classificação:")
print(classification_report(y_test, model.predict(X_test)))

# 6. Aplicar LIME
explainer = lime.lime_tabular.LimeTabularExplainer(
    training_data=X_train.values,
    feature_names=X.columns,
    class_names=['Bad', 'Good'],
    mode='classification'
)

i = 1  # índice de exemplo
exp = explainer.explain_instance(X_test.values[i], model.predict_proba, num_features=6)

# 7. Salvar explicação em imagem
fig = exp.as_pyplot_figure()
fig.savefig("images/lime_explanation_denied.png", bbox_inches='tight')

# (Opcional) Salvar modelo
joblib.dump(model, "model_rf.pkl")

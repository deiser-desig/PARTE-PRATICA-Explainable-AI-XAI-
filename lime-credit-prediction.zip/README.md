# 🧠 Decifrando a Caixa Preta: Tornando Modelos de IA Explicáveis com LIME

## 💼 Projeto
Este projeto desenvolve um modelo preditivo para análise de crédito bancário utilizando o dataset Statlog (German Credit Data) e aplica a técnica LIME para gerar explicações locais das previsões.

## 📁 Estrutura do Projeto
```
lime-credit-prediction/
├── data/                       # Dataset original ou link
├── images/                    # Imagens com explicações LIME
├── notebooks/                 # Notebooks com análise
├── main.py                    # Código principal do modelo + LIME
├── requirements.txt           # Dependências do projeto
└── README.md                  # Documentação
```

## 📊 Dataset
Utilizado o [Statlog (German Credit Data)](https://archive.ics.uci.edu/ml/datasets/statlog+(german+credit+data)) da UCI.

## 🚀 Como Executar
```bash
# Clone o repositório
git clone https://github.com/seu-usuario/lime-credit-prediction.git
cd lime-credit-prediction

# (Opcional) Crie um ambiente virtual
python -m venv venv
source venv/bin/activate  # Linux/Mac
venv\Scripts\activate   # Windows

# Instale as dependências
pip install -r requirements.txt

# Execute o script
python main.py
```

As explicações geradas pelo LIME serão salvas na pasta `images/`.

## 📌 Observações
- O dataset original deve estar salvo como `data/german_credit_data.csv`.
- As explicações LIME são geradas para uma instância de teste e salvas como imagem.